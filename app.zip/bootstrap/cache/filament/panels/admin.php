<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.appointment-resource.pages.create-appointment' => 'App\\Filament\\Resources\\AppointmentResource\\Pages\\CreateAppointment',
    'app.filament.resources.appointment-resource.pages.edit-appointment' => 'App\\Filament\\Resources\\AppointmentResource\\Pages\\EditAppointment',
    'app.filament.resources.appointment-resource.pages.list-appointments' => 'App\\Filament\\Resources\\AppointmentResource\\Pages\\ListAppointments',
    'app.filament.resources.doctor-resource.pages.create-doctor' => 'App\\Filament\\Resources\\DoctorResource\\Pages\\CreateDoctor',
    'app.filament.resources.doctor-resource.pages.edit-doctor' => 'App\\Filament\\Resources\\DoctorResource\\Pages\\EditDoctor',
    'app.filament.resources.doctor-resource.pages.list-doctors' => 'App\\Filament\\Resources\\DoctorResource\\Pages\\ListDoctors',
    'app.filament.resources.doctor-schedule-resource.pages.create-doctor-schedule' => 'App\\Filament\\Resources\\DoctorScheduleResource\\Pages\\CreateDoctorSchedule',
    'app.filament.resources.doctor-schedule-resource.pages.edit-doctor-schedule' => 'App\\Filament\\Resources\\DoctorScheduleResource\\Pages\\EditDoctorSchedule',
    'app.filament.resources.doctor-schedule-resource.pages.list-doctor-schedules' => 'App\\Filament\\Resources\\DoctorScheduleResource\\Pages\\ListDoctorSchedules',
    'app.filament.resources.medical-record-resource.pages.create-medical-record' => 'App\\Filament\\Resources\\MedicalRecordResource\\Pages\\CreateMedicalRecord',
    'app.filament.resources.medical-record-resource.pages.edit-medical-record' => 'App\\Filament\\Resources\\MedicalRecordResource\\Pages\\EditMedicalRecord',
    'app.filament.resources.medical-record-resource.pages.list-medical-records' => 'App\\Filament\\Resources\\MedicalRecordResource\\Pages\\ListMedicalRecords',
    'app.filament.resources.patient-resource.pages.create-patient' => 'App\\Filament\\Resources\\PatientResource\\Pages\\CreatePatient',
    'app.filament.resources.patient-resource.pages.edit-patient' => 'App\\Filament\\Resources\\PatientResource\\Pages\\EditPatient',
    'app.filament.resources.patient-resource.pages.list-patients' => 'App\\Filament\\Resources\\PatientResource\\Pages\\ListPatients',
    'app.filament.resources.patient-resource.pages.view-patient' => 'App\\Filament\\Resources\\PatientResource\\Pages\\ViewPatient',
    'app.filament.resources.permission-resource.pages.create-permission' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\CreatePermission',
    'app.filament.resources.permission-resource.pages.edit-permission' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\EditPermission',
    'app.filament.resources.permission-resource.pages.list-permissions' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\ListPermissions',
    'app.filament.resources.role-resource.pages.create-role' => 'App\\Filament\\Resources\\RoleResource\\Pages\\CreateRole',
    'app.filament.resources.role-resource.pages.edit-role' => 'App\\Filament\\Resources\\RoleResource\\Pages\\EditRole',
    'app.filament.resources.role-resource.pages.list-roles' => 'App\\Filament\\Resources\\RoleResource\\Pages\\ListRoles',
    'app.filament.resources.service-resource.pages.create-service' => 'App\\Filament\\Resources\\ServiceResource\\Pages\\CreateService',
    'app.filament.resources.service-resource.pages.edit-service' => 'App\\Filament\\Resources\\ServiceResource\\Pages\\EditService',
    'app.filament.resources.service-resource.pages.list-services' => 'App\\Filament\\Resources\\ServiceResource\\Pages\\ListServices',
    'app.filament.resources.service-type-resource.pages.create-service-type' => 'App\\Filament\\Resources\\ServiceTypeResource\\Pages\\CreateServiceType',
    'app.filament.resources.service-type-resource.pages.edit-service-type' => 'App\\Filament\\Resources\\ServiceTypeResource\\Pages\\EditServiceType',
    'app.filament.resources.service-type-resource.pages.list-service-types' => 'App\\Filament\\Resources\\ServiceTypeResource\\Pages\\ListServiceTypes',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'app.filament.widgets.latest-patients-table' => 'App\\Filament\\Widgets\\LatestPatientsTable',
    'app.filament.widgets.patients-count' => 'App\\Filament\\Widgets\\PatientsCount',
    'app.filament.widgets.today-appointments' => 'App\\Filament\\Widgets\\TodayAppointments',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament\\Resources\\AppointmentResource.php' => 'App\\Filament\\Resources\\AppointmentResource',
    'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament\\Resources\\DoctorResource.php' => 'App\\Filament\\Resources\\DoctorResource',
    'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament\\Resources\\DoctorScheduleResource.php' => 'App\\Filament\\Resources\\DoctorScheduleResource',
    'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament\\Resources\\MedicalRecordResource.php' => 'App\\Filament\\Resources\\MedicalRecordResource',
    'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament\\Resources\\PatientResource.php' => 'App\\Filament\\Resources\\PatientResource',
    'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament\\Resources\\PermissionResource.php' => 'App\\Filament\\Resources\\PermissionResource',
    'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament\\Resources\\RoleResource.php' => 'App\\Filament\\Resources\\RoleResource',
    'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament\\Resources\\ServiceResource.php' => 'App\\Filament\\Resources\\ServiceResource',
    'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament\\Resources\\ServiceTypeResource.php' => 'App\\Filament\\Resources\\ServiceTypeResource',
    'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament\\Widgets\\LatestPatientsTable.php' => 'App\\Filament\\Widgets\\LatestPatientsTable',
    'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament\\Widgets\\PatientsCount.php' => 'App\\Filament\\Widgets\\PatientsCount',
    'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament\\Widgets\\TodayAppointments.php' => 'App\\Filament\\Widgets\\TodayAppointments',
  ),
  'widgetDirectories' => 
  array (
    0 => 'D:\\DESARROLLO\\laragon\\www\\poli-web\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);