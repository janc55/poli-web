<x-layouts.app>
    {{-- Hero principal --}}
    <x-hero />

    <x-services/>

    <x-promotions/>

    <x-contact/>

    <!-- Más secciones aquí -->
</x-layouts.app>